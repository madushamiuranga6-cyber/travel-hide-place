# HIDEWORLD PLACE — “Discover the Hidden.”

A complete frontend travel-discovery platform for hidden, secret and underrated places
around the world. Built with **HTML5 + CSS3 + vanilla JavaScript** — no frameworks, no build step.

## Run it

Open `index.html` in any modern browser. That's it.

Optional (recommended for the clipboard share feature): serve locally —

```bash
cd hideworld-place
python3 -m http.server 8080
# then visit http://localhost:8080
```

## Pages

| Page | Purpose |
|---|---|
| `index.html` | Cinematic hero, featured & trending places, categories, stats |
| `explore.html` | Search, 8 filters, 4 sort orders, load-more pagination |
| `map.html` | Interactive demo map with coordinate markers + popups (Mapbox/Google-ready structure) |
| `categories.html` | 12 category cards with live counts |
| `countries.html` | 16 country cards with search |
| `place.html?id=N` | Dynamic details: info panel, tips, gallery + lightbox, mini-map, nearby places |
| `favorites.html` | localStorage-persisted favorites |
| `add-place.html` | Submission form → localStorage, with responsible-travel notice |
| `login.html` / `signup.html` | Demo auth (localStorage), structured for a real backend later |
| `about.html` | Mission, stats, Travel Responsibly pledge |
| `admin.html` | Dashboard UI: stats, places/users/submissions/categories/reports tabs |

## Data & storage (localStorage keys)

- `hw_favorites` — saved place ids
- `hw_submissions` — user-submitted places (appear in Explore/Map/Admin)
- `hw_users` / `hw_session` — demo auth

Sample dataset: 24 hidden destinations in `js/places.js`, each with coordinates,
tips, gallery and metadata. Swap `getAllPlaces()` for an API call when the backend arrives.

## Design system

Primary `#0B3D3A` · Secondary `#1F7A6E` · Accent `#F4B942` · Background `#F7F8F5` · Text `#17201E`
Fonts: Fraunces (headings) + Inter (body) via Google Fonts.

© 2026 HIDEWORLD PLACE. Travel responsibly.
