/* =========================================================
   HIDEWORLD PLACE — favorites.js
   Favorites page rendering (reads localStorage).
   ========================================================= */

(function () {
  'use strict';

  window.renderFavoritesPage = function () {
    const grid = document.getElementById('favorites-grid');
    if (!grid) return;
    const favs = hwGetFavs().map(id => getPlaceById(id)).filter(Boolean);
    const emptyBox = document.getElementById('favorites-empty');
    const fullBox = document.getElementById('favorites-full');

    if (!favs.length) {
      emptyBox.style.display = '';
      fullBox.style.display = 'none';
      return;
    }
    emptyBox.style.display = 'none';
    fullBox.style.display = '';
    document.getElementById('fav-count').textContent = favs.length;
    grid.innerHTML = favs.map(p => hwCard(p)).join('');
    hwInitReveal();
  };

  document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('favorites-grid')) window.renderFavoritesPage();
  });
})();
