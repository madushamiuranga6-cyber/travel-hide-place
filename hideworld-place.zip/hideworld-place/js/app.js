/* =========================================================
   HIDEWORLD PLACE — app.js
   Core UI: header/footer injection, nav, toasts, favorites,
   cards, search overlay, reveal animations, map page logic.
   ========================================================= */

(function () {
  'use strict';

  const LOGO_SVG = `<svg width="30" height="30" viewBox="0 0 32 32" fill="none" aria-hidden="true">
    <circle cx="16" cy="16" r="15" fill="#F4B942"/>
    <path d="M6 22 L13 9 L18 17 L21 12 L26 22 Z" fill="#0B3D3A"/>
    <circle cx="21.5" cy="8.5" r="2.4" fill="#0B3D3A"/></svg>`;

  const ICON_SEARCH = `<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>`;
  const ICON_HEART = `<svg viewBox="0 0 24 24"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21.2l7.8-7.8 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg>`;
  const ICON_STAR = `<svg width="15" height="15" viewBox="0 0 24 24" fill="#F4B942" stroke="#F4B942" stroke-width="1.4"><path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.2 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8z"/></svg>`;
  const ICON_PIN = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>`;
  const ICON_SAVE = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>`;
  const ICON_ARROW = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`;

  window.HW_ICONS = { ICON_HEART, ICON_STAR, ICON_PIN, ICON_SAVE, ICON_ARROW };

  /* ---------- Toasts ---------- */
  function toast(msg, type) {
    let stack = document.querySelector('.toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'toast-stack';
      document.body.appendChild(stack);
    }
    const el = document.createElement('div');
    el.className = 'toast' + (type === 'accent' ? ' toast-accent' : type === 'warn' ? ' toast-warn' : '');
    el.textContent = msg;
    stack.appendChild(el);
    setTimeout(() => {
      el.classList.add('out');
      setTimeout(() => el.remove(), 320);
    }, 2600);
  }
  window.hwToast = toast;

  /* ---------- Favorites ---------- */
  function getFavs() {
    try { return JSON.parse(localStorage.getItem('hw_favorites') || '[]'); }
    catch (e) { return []; }
  }
  function isFav(id) { return getFavs().includes(Number(id)); }
  function toggleFav(id) {
    id = Number(id);
    let favs = getFavs();
    const adding = !favs.includes(id);
    favs = adding ? favs.concat(id) : favs.filter(f => f !== id);
    localStorage.setItem('hw_favorites', JSON.stringify(favs));
    toast(adding ? '❤️ Added to favorites' : '💚 Removed from favorites', adding ? 'accent' : undefined);
    document.querySelectorAll(`[data-fav-id="${id}"]`).forEach(btn => {
      btn.classList.toggle('faved', adding);
      btn.classList.add('pop');
      setTimeout(() => btn.classList.remove('pop'), 480);
      const label = btn.querySelector('.fav-label');
      if (label) label.textContent = adding ? 'Saved' : 'Save';
    });
    if (document.body.dataset.page === 'favorites') renderFavoritesPage();
    return adding;
  }
  window.hwToggleFav = toggleFav;
  window.hwGetFavs = getFavs;

  /* ---------- Header / Footer ---------- */
  const NAV_LINKS = [
    ['index.html', 'Home'], ['explore.html', 'Explore'], ['map.html', 'Map'],
    ['categories.html', 'Categories'], ['countries.html', 'Countries'],
    ['add-place.html', 'Add Place'], ['about.html', 'About']
  ];

  function currentUser() {
    try { return JSON.parse(localStorage.getItem('hw_session') || 'null'); }
    catch (e) { return null; }
  }
  window.hwCurrentUser = currentUser;

  function buildHeader() {
    const header = document.getElementById('site-header');
    if (!header) return;
    const page = document.body.dataset.page || '';
    header.className = 'site-header' + (document.body.dataset.solidHeader === 'true' ? ' solid' : '');

    const links = NAV_LINKS.map(([href, label]) =>
      `<a href="${href}" class="${page === label.toLowerCase().replace(' ', '') || (label === 'Home' && page === 'home') ? 'active' : ''}">${label}</a>`).join('');
    const mobileLinks = NAV_LINKS.concat([['favorites.html', 'Favorites']]).map(([href, label]) =>
      `<a href="${href}">${label} <span>→</span></a>`).join('');

    const user = currentUser();
    const authArea = user
      ? `<div class="user-chip" id="user-chip">
           <span class="user-avatar">${esc(user.name.charAt(0).toUpperCase())}</span>
           <span>${esc(user.name.split(' ')[0])}</span>
           <div class="user-menu" id="user-menu">
             <a href="favorites.html">❤️ My Favorites</a>
             <a href="admin.html">📊 Admin Dashboard</a>
             <button id="logout-btn">↩ Log out</button>
           </div>
         </div>`
      : `<div class="nav-auth">
           <a href="login.html" class="btn btn-ghost btn-sm">Login</a>
           <a href="signup.html" class="btn btn-accent btn-sm">Sign Up</a>
         </div>`;

    header.innerHTML = `
      <div class="container nav-inner">
        <a class="logo" href="index.html">${LOGO_SVG} HIDEWORLD <span style="color:var(--accent)">PLACE</span></a>
        <nav class="main-nav" aria-label="Main navigation">${links}</nav>
        <div class="nav-actions">
          <button class="icon-btn" id="search-open" aria-label="Search">${ICON_SEARCH}</button>
          ${authArea}
          <button class="hamburger" id="hamburger" aria-label="Menu"><span></span><span></span><span></span></button>
        </div>
      </div>`;

    const mobile = document.createElement('div');
    mobile.className = 'mobile-menu';
    mobile.id = 'mobile-menu';
    mobile.innerHTML = `<button class="mobile-close" id="mobile-close" aria-label="Close">×</button>${mobileLinks}
      <div style="margin-top:22px;display:flex;gap:12px">
        ${user ? `<button class="btn btn-ghost btn-sm" id="m-logout">Log out</button>` : `<a href="login.html" class="btn btn-ghost btn-sm">Login</a><a href="signup.html" class="btn btn-accent btn-sm">Sign Up</a>`}
      </div>`;
    document.body.appendChild(mobile);

    const ham = document.getElementById('hamburger');
    ham.addEventListener('click', () => {
      ham.classList.toggle('open');
      document.getElementById('mobile-menu').classList.toggle('open');
      document.body.style.overflow = ham.classList.contains('open') ? 'hidden' : '';
    });
    document.getElementById('mobile-close').addEventListener('click', closeMobile);
    function closeMobile() {
      ham.classList.remove('open');
      document.getElementById('mobile-menu').classList.remove('open');
      document.body.style.overflow = '';
    }

    if (user) {
      const chip = document.getElementById('user-chip');
      const menu = document.getElementById('user-menu');
      chip.addEventListener('click', e => { if (!menu.contains(e.target)) menu.classList.toggle('open'); });
      document.addEventListener('click', e => { if (!chip.contains(e.target)) menu.classList.remove('open'); });
      document.getElementById('logout-btn').addEventListener('click', e => {
        e.stopPropagation(); logout();
      });
      const mLogout = document.getElementById('m-logout');
      if (mLogout) mLogout.addEventListener('click', logout);
    }
    function logout() {
      localStorage.removeItem('hw_session');
      toast('👋 Logged out successfully', 'accent');
      setTimeout(() => location.href = 'index.html', 700);
    }

    const searchBtn = document.getElementById('search-open');
    if (searchBtn) searchBtn.addEventListener('click', openSearchOverlay);

    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });
  }

  function buildFooter() {
    const footer = document.getElementById('site-footer');
    if (!footer) return;
    footer.className = 'site-footer';
    footer.innerHTML = `
      <div class="container">
        <div class="footer-top">
          <div class="footer-brand">
            <a class="logo" href="index.html">${LOGO_SVG} HIDEWORLD <span style="color:var(--accent)">PLACE</span></a>
            <p>Discover the hidden side of the world. Secret beaches, forgotten villages, and places beyond the ordinary — curated by explorers like you.</p>
            <div class="socials">
              <a href="#" aria-label="Instagram" data-social="Instagram"><svg viewBox="0 0 24 24"><path d="M12 2.2c3.2 0 3.6 0 4.9.1 3.3.1 4.8 1.7 4.9 4.9.1 1.3.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 3.2-1.7 4.8-4.9 4.9-1.3.1-1.6.1-4.9.1-3.2 0-3.6 0-4.8-.1-3.3-.1-4.8-1.7-4.9-4.9-.1-1.3-.1-1.6-.1-4.8s0-3.6.1-4.8C2.4 4 4 2.4 7.2 2.3c1.2-.1 1.6-.1 4.8-.1zM12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0 8.2a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4zm5.2-9.4a1.2 1.2 0 1 0 0 2.4 1.2 1.2 0 0 0 0-2.4z"/></svg></a>
              <a href="#" aria-label="Facebook" data-social="Facebook"><svg viewBox="0 0 24 24"><path d="M24 12.07C24 5.4 18.63 0 12 0S0 5.4 0 12.07C0 18.1 4.39 23.09 10.13 24v-8.44H7.08v-3.49h3.04V9.41c0-3.02 1.8-4.7 4.54-4.7 1.31 0 2.68.24 2.68.24v2.97h-1.5c-1.5 0-1.96.93-1.96 1.89v2.26h3.32l-.53 3.49h-2.8V24C19.62 23.1 24 18.1 24 12.07z"/></svg></a>
              <a href="#" aria-label="YouTube" data-social="YouTube"><svg viewBox="0 0 24 24"><path d="M23.5 6.19a3.02 3.02 0 0 0-2.12-2.14C19.5 3.55 12 3.55 12 3.55s-7.5 0-9.38.5A3.02 3.02 0 0 0 .5 6.19C0 8.07 0 12 0 12s0 3.93.5 5.81a3.02 3.02 0 0 0 2.12 2.14c1.88.5 9.38.5 9.38.5s7.5 0 9.38-.5a3.02 3.02 0 0 0 2.12-2.14C24 15.93 24 12 24 12s0-3.93-.5-5.81zM9.55 15.57V8.43L15.82 12l-6.27 3.57z"/></svg></a>
              <a href="#" aria-label="TikTok" data-social="TikTok"><svg viewBox="0 0 24 24"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1 0-5.78c.28 0 .54.04.79.1v-3.5a6.37 6.37 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.3a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V8.75a8.24 8.24 0 0 0 4.83 1.55v-3.4a4.85 4.85 0 0 1-1.07-.21z"/></svg></a>
            </div>
          </div>
          <div class="footer-col">
            <h4>Discover</h4>
            <ul>
              <li><a href="explore.html">Explore</a></li>
              <li><a href="categories.html">Categories</a></li>
              <li><a href="countries.html">Countries</a></li>
              <li><a href="map.html">Map</a></li>
              <li><a href="favorites.html">Favorites</a></li>
            </ul>
          </div>
          <div class="footer-col">
            <h4>Community</h4>
            <ul>
              <li><a href="add-place.html">Add a Place</a></li>
              <li><a href="about.html">About Us</a></li>
              <li><a href="about.html#responsible">Travel Responsibly</a></li>
              <li><a href="admin.html">Admin</a></li>
            </ul>
          </div>
          <div class="footer-col footer-news">
            <h4>Stay in the Loop</h4>
            <p>Get one hidden gem in your inbox every week. No spam, ever.</p>
            <form class="news-form" id="news-form">
              <input type="email" placeholder="Your email address" required aria-label="Email">
              <button type="submit">Join</button>
            </form>
          </div>
        </div>
        <div class="footer-bottom">
          <span>© 2026 HIDEWORLD PLACE. All rights reserved.</span>
          <span>Made for explorers · <a href="about.html#responsible" style="color:var(--accent)">Travel Responsibly</a></span>
        </div>
      </div>`;

    const newsForm = document.getElementById('news-form');
    newsForm.addEventListener('submit', e => {
      e.preventDefault();
      toast('✅ Subscribed! Welcome to the hidden world.', 'accent');
      newsForm.reset();
    });
    footer.querySelectorAll('[data-social]').forEach(a => {
      a.addEventListener('click', e => {
        e.preventDefault();
        toast('🔗 ' + a.dataset.social + ' page opening soon');
      });
    });
  }

  /* ---------- Place card template ---------- */
  window.hwCard = function (p, rank) {
    const faved = isFav(p.id);
    return `
    <article class="place-card reveal">
      <div class="card-media">
        <a href="place.html?id=${p.id}"><img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'"></a>
        ${rank ? `<span class="trend-rank">${String(rank).padStart(2, '0')}</span>` : ''}
        <div class="card-badges">
          <span class="badge">${esc(p.category)}</span>
          ${p.popularity === 'Trending' ? '<span class="badge badge-accent">🔥 Trending</span>' : ''}
        </div>
        <button class="fav-btn ${faved ? 'faved' : ''}" data-fav-id="${p.id}" aria-label="Save to favorites">${ICON_HEART}</button>
      </div>
      <div class="card-body">
        <span class="card-loc">${ICON_PIN} ${esc(p.country)}</span>
        <h3><a href="place.html?id=${p.id}">${esc(p.name)}</a></h3>
        <p>${esc(p.description)}</p>
        <div class="card-meta">
          <span class="rating">${ICON_STAR} ${Number(p.rating).toFixed(1)}</span>
          <span class="saves">${ICON_SAVE} ${Number(p.saves || 0).toLocaleString()} saves</span>
          <span>${esc(p.difficulty)}</span>
        </div>
        <div class="card-actions">
          <a href="place.html?id=${p.id}" class="btn btn-primary btn-sm">View Details</a>
        </div>
      </div>
    </article>`;
  };

  /* ---------- Search overlay ---------- */
  function openSearchOverlay() {
    let ov = document.getElementById('search-overlay');
    if (!ov) {
      ov = document.createElement('div');
      ov.className = 'search-overlay';
      ov.id = 'search-overlay';
      ov.innerHTML = `
        <div class="search-panel">
          <div class="search-panel-head">
            ${ICON_SEARCH}
            <input type="text" id="overlay-search-input" placeholder="Search hidden places, countries, categories..." autocomplete="off">
            <button class="close-x" id="overlay-close" aria-label="Close">×</button>
          </div>
          <div class="search-results" id="overlay-results"></div>
        </div>`;
      document.body.appendChild(ov);
      ov.addEventListener('click', e => { if (e.target === ov) closeSearch(); });
      document.getElementById('overlay-close').addEventListener('click', closeSearch);
      document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSearch(); });
      document.getElementById('overlay-search-input').addEventListener('input', renderOverlayResults);
    }
    ov.classList.add('open');
    document.body.style.overflow = 'hidden';
    renderOverlayResults();
    setTimeout(() => document.getElementById('overlay-search-input').focus(), 120);
  }
  function closeSearch() {
    const ov = document.getElementById('search-overlay');
    if (ov) ov.classList.remove('open');
    document.body.style.overflow = '';
  }
  window.hwOpenSearch = openSearchOverlay;

  function renderOverlayResults() {
    const q = (document.getElementById('overlay-search-input').value || '').trim().toLowerCase();
    const box = document.getElementById('overlay-results');
    let items = getAllPlaces();
    if (q) {
      items = items.filter(p =>
        [p.name, p.country, p.region, p.category].join(' ').toLowerCase().includes(q));
    } else {
      items = items.slice().sort((a, b) => b.saves - a.saves).slice(0, 6);
    }
    if (!items.length) {
      box.innerHTML = `<div class="search-empty"><div style="font-size:2rem">🧭</div><p>No hidden places found.</p></div>`;
      return;
    }
    box.innerHTML = (q ? '' : '<p style="padding:6px 12px;color:var(--muted);font-size:.8rem;letter-spacing:.08em;text-transform:uppercase">Trending now</p>') +
      items.slice(0, 8).map(p => `
        <a class="search-hit" href="place.html?id=${p.id}">
          <img src="${esc(p.image)}" alt="" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">
          <div><h4>${esc(p.name)}</h4><span>${esc(p.country)} · ${esc(p.category)} · ★ ${Number(p.rating).toFixed(1)}</span></div>
        </a>`).join('');
  }

  /* ---------- Global click delegation ---------- */
  document.addEventListener('click', e => {
    const favBtn = e.target.closest('[data-fav-id]');
    if (favBtn) { toggleFav(favBtn.dataset.favId); return; }
    const shareBtn = e.target.closest('[data-share]');
    if (shareBtn) {
      e.preventDefault();
      shareLink(shareBtn.dataset.share);
    }
  });

  function shareLink(url) {
    const full = location.origin === 'null' || location.protocol === 'file:'
      ? url : location.origin + location.pathname.replace(/[^/]*$/, '') + url;
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(full).then(
        () => toast('🔗 Link copied'),
        () => fallbackCopy(full)
      );
    } else fallbackCopy(full);
  }
  function fallbackCopy(text) {
    const ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('🔗 Link copied'); }
    catch (e) { toast('⚠️ Copy failed — long-press the URL instead', 'warn'); }
    ta.remove();
  }
  window.hwShare = shareLink;

  /* ---------- Reveal on scroll ---------- */
  function initReveal() {
    const els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) { els.forEach(el => el.classList.add('in')); return; }
    const io = new IntersectionObserver(entries => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          en.target.classList.add('in');
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.08 });
    els.forEach((el, i) => {
      el.style.transitionDelay = (i % 3) * 70 + 'ms';
      io.observe(el);
    });
  }
  window.hwInitReveal = initReveal;

  /* ---------- Counter animation ---------- */
  window.hwCountUp = function (el, target, suffix) {
    const dur = 1400, t0 = performance.now();
    function tick(t) {
      const k = Math.min(1, (t - t0) / dur);
      const eased = 1 - Math.pow(1 - k, 3);
      el.textContent = Math.round(target * eased).toLocaleString() + (suffix || '');
      if (k < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  };

  /* =========================================================
     MAP PAGE
     ========================================================= */
  function initMapPage() {
    const canvas = document.getElementById('map-canvas');
    if (!canvas) return;

    // Populate filter dropdowns
    document.getElementById('map-category').innerHTML = '<option value="">All categories</option>' +
      getCategoriesWithCounts().map(c => `<option value="${esc(c.name)}">${c.icon} ${esc(c.name)}</option>`).join('');
    document.getElementById('map-country').innerHTML = '<option value="">All countries</option>' +
      getCountriesWithCounts().filter(c => c.count > 0)
        .map(c => `<option value="${esc(c.name)}">${c.flag} ${esc(c.name)}</option>`).join('');

    const markers = new Map();
    const popup = document.createElement('div');
    popup.className = 'map-popup';
    popup.style.display = 'none';
    canvas.appendChild(popup);

    function project(lat, lng) {
      const x = Math.max(3, Math.min(97, (lng + 180) / 360 * 100));
      const y = Math.max(4, Math.min(96, (90 - lat) / 180 * 100));
      return [x, y];
    }

    function filtered() {
      const q = (document.getElementById('map-search').value || '').trim().toLowerCase();
      const cat = document.getElementById('map-category').value;
      const cty = document.getElementById('map-country').value;
      const minR = parseFloat(document.getElementById('map-rating').value) || 0;
      return getAllPlaces().filter(p =>
        (!q || [p.name, p.country, p.region].join(' ').toLowerCase().includes(q)) &&
        (!cat || p.category === cat) &&
        (!cty || p.country === cty) &&
        Number(p.rating) >= minR
      );
    }

    function renderMarkers() {
      markers.forEach(m => m.remove());
      markers.clear();
      popup.style.display = 'none';
      const list = filtered();
      document.getElementById('map-count').textContent = list.length + ' places shown';
      list.forEach(p => {
        const [x, y] = project(p.latitude, p.longitude);
        const m = document.createElement('div');
        m.className = 'map-marker';
        m.style.left = x + '%';
        m.style.top = y + '%';
        m.innerHTML = '<span class="pulse"></span><span class="pin"></span>';
        m.title = p.name;
        m.addEventListener('click', ev => { ev.stopPropagation(); showPopup(p, m); });
        canvas.appendChild(m);
        markers.set(p.id, m);
      });
      const listBox = document.getElementById('map-list');
      listBox.innerHTML = list.map(p => `
        <a class="search-hit" href="place.html?id=${p.id}">
          <img src="${esc(p.image)}" alt="" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">
          <div><h4>${esc(p.name)}</h4><span>${esc(p.country)} · ★ ${Number(p.rating).toFixed(1)}</span></div>
        </a>`).join('') || '<p style="color:var(--muted);padding:14px">No hidden places found.</p>';
    }

    function showPopup(p, marker) {
      markers.forEach(m => m.classList.remove('active'));
      marker.classList.add('active');
      popup.innerHTML = `
        <button class="popup-close" aria-label="Close">×</button>
        <img src="${esc(p.image)}" alt="${esc(p.name)}" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">
        <div class="popup-body">
          <h4>${esc(p.name)}</h4>
          <div class="popup-meta"><span>${esc(p.country)}</span><span>★ ${Number(p.rating).toFixed(1)}</span></div>
          <a class="btn btn-primary btn-sm btn-block" href="place.html?id=${p.id}">View Details</a>
        </div>`;
      popup.style.left = marker.style.left;
      popup.style.top = marker.style.top;
      popup.style.display = 'block';
      popup.querySelector('.popup-close').addEventListener('click', e => {
        e.stopPropagation(); popup.style.display = 'none'; marker.classList.remove('active');
      });
    }
    canvas.addEventListener('click', () => {
      popup.style.display = 'none';
      markers.forEach(m => m.classList.remove('active'));
    });

    ['map-search', 'map-category', 'map-country', 'map-rating'].forEach(id => {
      document.getElementById(id).addEventListener('input', renderMarkers);
      document.getElementById(id).addEventListener('change', renderMarkers);
    });

    let zoom = 1;
    const viewport = canvas; // zoom transforms the canvas itself
    document.getElementById('zoom-in').addEventListener('click', () => setZoom(zoom + 0.2));
    document.getElementById('zoom-out').addEventListener('click', () => setZoom(zoom - 0.2));
    function setZoom(z) {
      zoom = Math.max(1, Math.min(2.2, z));
      viewport.style.transform = zoom === 1 ? 'none' : `scale(${zoom})`;
      viewport.style.transformOrigin = 'center';
    }

    renderMarkers();
  }

  /* ---------- Lightbox ---------- */
  window.hwLightbox = function (src) {
    let lb = document.getElementById('lightbox');
    if (!lb) {
      lb = document.createElement('div');
      lb.className = 'lightbox'; lb.id = 'lightbox';
      lb.innerHTML = '<button class="lb-close" aria-label="Close">×</button><img alt="">';
      document.body.appendChild(lb);
      lb.addEventListener('click', e => { if (e.target !== lb.querySelector('img')) lb.classList.remove('open'); });
    }
    lb.querySelector('img').src = src;
    lb.classList.add('open');
  };

  /* ---------- Boot ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    buildHeader();
    buildFooter();
    initReveal();
    initMapPage();
    if (typeof window.hwPageInit === 'function') window.hwPageInit();
  });
})();
