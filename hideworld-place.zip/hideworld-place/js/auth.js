/* =========================================================
   HIDEWORLD PLACE — auth.js
   Demo authentication with localStorage.
   Swap the storage functions for real API calls later.
   ========================================================= */

(function () {
  'use strict';

  function getUsers() {
    try { return JSON.parse(localStorage.getItem('hw_users') || '[]'); }
    catch (e) { return []; }
  }
  function saveUsers(users) { localStorage.setItem('hw_users', JSON.stringify(users)); }

  function msg(form, text, ok) {
    const el = form.querySelector('.form-msg');
    el.textContent = text;
    el.className = 'form-msg ' + (ok ? 'success' : 'error');
  }

  /* ---------- SIGN UP ---------- */
  const signupForm = document.getElementById('signup-form');
  if (signupForm) {
    signupForm.addEventListener('submit', e => {
      e.preventDefault();
      const name = document.getElementById('su-name').value.trim();
      const email = document.getElementById('su-email').value.trim().toLowerCase();
      const pass = document.getElementById('su-pass').value;
      const pass2 = document.getElementById('su-pass2').value;

      if (name.length < 2) return msg(signupForm, 'Please enter your full name.', false);
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return msg(signupForm, 'Please enter a valid email address.', false);
      if (pass.length < 6) return msg(signupForm, 'Password must be at least 6 characters.', false);
      if (pass !== pass2) return msg(signupForm, 'Passwords do not match.', false);

      const users = getUsers();
      if (users.some(u => u.email === email)) return msg(signupForm, 'An account with this email already exists.', false);

      users.push({ name, email, pass, joined: new Date().toISOString() });
      saveUsers(users);
      localStorage.setItem('hw_session', JSON.stringify({ name, email }));
      msg(signupForm, '✅ Account created! Redirecting...', true);
      hwToast('🎉 Welcome to HIDEWORLD, ' + name.split(' ')[0] + '!', 'accent');
      setTimeout(() => location.href = 'index.html', 1100);
    });
  }

  /* ---------- LOGIN ---------- */
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', e => {
      e.preventDefault();
      const email = document.getElementById('li-email').value.trim().toLowerCase();
      const pass = document.getElementById('li-pass').value;
      const remember = document.getElementById('li-remember').checked;

      const user = getUsers().find(u => u.email === email && u.pass === pass);
      if (!user) return msg(loginForm, 'Invalid email or password.', false);

      localStorage.setItem('hw_session', JSON.stringify({ name: user.name, email: user.email }));
      if (!remember) sessionStorage.setItem('hw_session_volatile', '1');
      msg(loginForm, '✅ Login successful! Redirecting...', true);
      hwToast('👋 Welcome back, ' + user.name.split(' ')[0] + '!', 'accent');
      setTimeout(() => location.href = 'index.html', 900);
    });

    const forgot = document.getElementById('forgot-link');
    if (forgot) forgot.addEventListener('click', e => {
      e.preventDefault();
      hwToast('📧 Password reset link sent (demo)', 'warn');
    });
  }
})();
