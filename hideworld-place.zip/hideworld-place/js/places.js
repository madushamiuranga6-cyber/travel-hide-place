/* =========================================================
   HIDEWORLD PLACE — places.js
   Sample destination data + shared data helpers.
   Backend-ready: replace getAllPlaces() with an API call later.
   ========================================================= */

const U = (id, w = 1200) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;
const FALLBACK_IMG = U('1506744038136-46273834b3fb');

const PLACES = [
  {
    id: 1, name: 'Ella Secret Falls', country: 'Sri Lanka', region: 'Sabaragamuwa',
    category: 'Hidden Waterfalls',
    description: 'A three-tier waterfall tucked deep inside a tea-estate forest, reachable only by a narrow jungle trail.',
    longDescription: 'Ella Secret Falls cascades down moss-covered rock into a crystal pool that few travelers ever see. The hike in follows an old estate track past cinnamon trees and wild pepper vines, ending at a swimming hole framed by ferns. Go early in the morning for mist, birdsong and the falls entirely to yourself.',
    image: U('1433086966358-54859d0ed716'),
    gallery: [U('1433086966358-54859d0ed716'), U('1500534314209-a25ddb2bd429'), U('1447752875215-b2761acb3c5d')],
    rating: 4.9, saves: 2841, cost: '$', difficulty: 'Medium', bestTime: 'May – September',
    transport: 'Tuk-tuk to Ella Rock trailhead, then 45 min jungle trek',
    popularity: 'Hidden Gem', latitude: 6.8767, longitude: 81.0461,
    tips: ['Hire a local guide from Ella town for the unmarked final section.', 'Wear grip shoes — rocks near the pool are slippery.', 'Avoid monsoon months (Oct–Jan); the trail floods.']
  },
  {
    id: 2, name: 'Atuh Hidden Lagoon', country: 'Indonesia', region: 'Nusa Penida, Bali',
    category: 'Secret Lagoons',
    description: 'A turquoise lagoon sealed inside towering limestone cliffs on Nusa Penida\'s wild east coast.',
    longDescription: 'Hidden beneath the cliffs near Atuh Beach, this lagoon appears only at mid-to-low tide through a cave-like opening. The water glows an impossible shade of turquoise, and the surrounding karst walls echo with the sound of waves. It feels less like a beach and more like a natural cathedral.',
    image: U('1530789253388-582c481c54b0'),
    gallery: [U('1530789253388-582c481c54b0'), U('1544551763-46a013bb70d5'), U('1506929562872-bb421503ef21')],
    rating: 4.8, saves: 3512, cost: '$$', difficulty: 'Hard', bestTime: 'April – October',
    transport: 'Scooter to Atuh Beach car park, then steep cliff stairs',
    popularity: 'Trending', latitude: -8.7505, longitude: 115.5506,
    tips: ['Check the tide chart — the lagoon is unsafe at high tide.', 'Bring water; there are no vendors on the lagoon side.', 'Combine with a sunrise visit to Atuh Beach viewpoint.']
  },
  {
    id: 3, name: 'Civita di Bagnoregio', country: 'Italy', region: 'Lazio',
    category: 'Forgotten Villages',
    description: 'A medieval hilltop village fading into the valley mists, reachable only by a long footbridge.',
    longDescription: 'Known as "the dying town," Civita sits on a crumbling tufa plateau isolated from the modern world. Cross the pedestrian bridge and you step into the 14th century — stone archways, a single piazza, and silence broken only by swallows. At dawn, fog fills the valley and the village appears to float in the sky.',
    image: U('1516483638261-f4dbaf036963'),
    gallery: [U('1516483638261-f4dbaf036963'), U('1523906834658-6e24ef2386f9'), U('1476514525535-07fb3b4ae5f1')],
    rating: 4.9, saves: 4103, cost: '$$', difficulty: 'Easy', bestTime: 'April – June',
    transport: 'Bus from Orvieto, then the 300 m footbridge walk',
    popularity: 'Well Kept Secret', latitude: 42.6276, longitude: 12.1097,
    tips: ['Stay overnight — day-trippers leave by 5 pm.', 'The bridge climb is steep but manageable for most.', 'Visit the geological museum at the entrance for context.']
  },
  {
    id: 4, name: 'Phraya Nakhon Cave', country: 'Thailand', region: 'Prachuap Khiri Khan',
    category: 'Hidden Caves',
    description: 'A royal pavilion glowing inside a colossal collapsed cave, lit by a single shaft of sunlight.',
    longDescription: 'Hidden inside Khao Sam Roi Yot National Park, this cave hides a four-gabled pavilion built for King Chulalongkorn in 1890. Late morning light falls through the collapsed ceiling onto the golden pavilion like a spotlight. The walk in crosses two white-sand beaches and a hilltop viewpoint.',
    image: U('1504280317859-8d10cb95a2a6'),
    gallery: [U('1504280317859-8d10cb95a2a6'), U('1469474968028-56623f02e42e'), U('1507525428034-b723cf961d3e')],
    rating: 4.8, saves: 2966, cost: '$', difficulty: 'Medium', bestTime: 'November – February',
    transport: 'Boat from Bang Pu village, then a 430 m hill climb',
    popularity: 'Trending', latitude: 12.1878, longitude: 100.0169,
    tips: ['Arrive before 10:30 am to see the light beam on the pavilion.', 'Boat operators stop running in rough seas.', 'Bring a torch for the darker cave chambers.']
  },
  {
    id: 5, name: 'Aokigahara Sea of Trees', country: 'Japan', region: 'Yamanashi, Mt. Fuji',
    category: 'Hidden Forests',
    description: 'A wind-carved lava forest at Fuji\'s base where trees twist over hardened volcanic rock.',
    longDescription: 'Formed after a 9th-century eruption, Aokigahara\'s dense canopy blocks the wind — and much of the light. Moss swallows the sound of your footsteps on trails that wind between tree roots gripping black lava. Stick to the marked paths and you\'ll find an otherworldly calm unlike anywhere else in Japan.',
    image: U('1447752875215-b2761acb3c5d'),
    gallery: [U('1447752875215-b2761acb3c5d'), U('1441974231531-c6227db76b6e'), U('1470071459604-3b5ec3a7fe05')],
    rating: 4.7, saves: 2230, cost: '$', difficulty: 'Easy', bestTime: 'October – November',
    transport: 'Bus to Kawaguchiko, then a short walk from the Ice Cave bus stop',
    popularity: 'Hidden Gem', latitude: 35.4720, longitude: 138.6570,
    tips: ['Stay on marked trails; the forest is famously disorienting.', 'The Wind Cave and Ice Cave make great add-ons.', 'Autumn weekends get busy — go on a weekday.']
  },
  {
    id: 6, name: 'Nar Phu Hidden Valley', country: 'Nepal', region: 'Annapurna, Mustang',
    category: 'Hidden Valleys',
    description: 'A restricted medieval valley of stone villages beneath 7,000 m peaks on the old salt route.',
    longDescription: 'Beyond a landslide-prone gorge off the Annapurna Circuit lies Nar Phu — two Tibetan villages frozen in time. Colorful chortens guard narrow lanes, snow leopards patrol the ridgelines above, and the only traffic is yak caravans. A special permit keeps crowds away, preserving a way of life centuries old.',
    image: U('1544735716-392fe2489ffa'),
    gallery: [U('1544735716-392fe2489ffa'), U('1464822759023-fed622ff2c3b'), U('1519681393784-d120267933ba')],
    rating: 4.9, saves: 1874, cost: '$$$', difficulty: 'Hard', bestTime: 'October – November',
    transport: 'Jeep from Besisahar to Koto, then 2-day trek with permit check',
    popularity: 'Hidden Gem', latitude: 28.6500, longitude: 84.2200,
    tips: ['A restricted-area permit is required — arrange in Kathmandu.', 'Teahouses are basic; bring a warm sleeping bag.', 'Acclimatize properly before crossing Kang La pass.']
  },
  {
    id: 7, name: 'Gjipe Canyon Beach', country: 'Albania', region: 'Himara, Riviera',
    category: 'Hidden Beaches',
    description: 'A pebble beach at the mouth of a river canyon, guarded by 100 m white cliffs.',
    longDescription: 'Where the Gjipe River meets the Ionian Sea, a beach hides at the end of a 30-minute canyon walk. Freshwater pools sit just steps from saltwater, and the cliffs block the afternoon wind. Camp under the stars here and you\'ll hear nothing but the river and the sea.',
    image: U('1507525428034-b723cf961d3e'),
    gallery: [U('1507525428034-b723cf961d3e'), U('1519046904884-53103b34b206'), U('1505142468610-359e7d316be0')],
    rating: 4.8, saves: 2689, cost: '$', difficulty: 'Medium', bestTime: 'June – September',
    transport: 'Hike from Gjipe Canyon viewpoint or boat from Himara',
    popularity: 'Trending', latitude: 40.0319, longitude: 19.7092,
    tips: ['Bring supplies — no shops at the beach.', 'A basic campground operates May to October.', 'The canyon walk has some scrambling sections.']
  },
  {
    id: 8, name: 'Lake Kaindy Underwater Forest', country: 'Kazakhstan', region: 'Tian Shan',
    category: 'Secret Mountains',
    description: 'A mountain lake where the trunks of drowned spruce trees still pierce the surface.',
    longDescription: 'Born from a 1911 earthquake landslide, Lake Kaindy is famous among divers and photographers: submerged spruce trees create an eerie underwater forest, while above the surface their bare trunks stand like masts. The lake\'s milky turquoise color comes from limestone deposits in the water.',
    image: U('1439066615861-d1af74d74000'),
    gallery: [U('1439066615861-d1af74d74000'), U('1501785888041-af3ef285b470'), U('1531366936337-7c912a4589a7')],
    rating: 4.7, saves: 1542, cost: '$$', difficulty: 'Hard', bestTime: 'July – September',
    transport: '4x4 from Saty village over rough mountain roads',
    popularity: 'Hidden Gem', latitude: 42.9865, longitude: 78.4628,
    tips: ['Water temperature stays near 6°C — dry suits only for diving.', 'Combine with Charyn Canyon on the same trip.', 'Roads close in winter; check conditions locally.']
  },
  {
    id: 9, name: 'Svalbard Secret Glacier Camp', country: 'Norway', region: 'Svalbard Archipelago',
    category: 'Secret Campsites',
    description: 'A wilderness camp on the polar tundra beneath blue ice, guarded by the midnight sun.',
    longDescription: 'Far above the Arctic Circle, guided expeditions pitch camp on the moraines of a retreating glacier. You sleep in expedition tents surrounded by ice formations older than civilization, with reindeer wandering past and — if you\'re lucky — the northern lights dancing overhead.',
    image: U('1519681393784-d120267933ba'),
    gallery: [U('1519681393784-d120267933ba'), U('1478827387698-1527781a4887b'), U('1472214103451-9374bd1c798e')],
    rating: 4.9, saves: 1211, cost: '$$$', difficulty: 'Hard', bestTime: 'March – May',
    transport: 'Organized expedition from Longyearbyen',
    popularity: 'Hidden Gem', latitude: 78.2232, longitude: 15.6267,
    tips: ['Only travel with armed, certified guides — polar bears are active.', 'Polar night (Nov–Jan) offers aurora but no daylight.', 'Book months ahead; expedition slots are limited.']
  },
  {
    id: 10, name: 'Zhangjiajie Silent Pillars', country: 'China', region: 'Hunan',
    category: 'Secret Viewpoints',
    description: 'Sandstone towers rising from sea-of-clouds mist, best seen from unmarked trail overlooks.',
    longDescription: 'While tour groups crowd the glass bridge and Bailong Elevator, the old stone-step trails of Zhangjiajie\'s western rim lead to empty overlooks where 3,000 quartzite pillars float in and out of cloud. Arrive at dawn in shoulder season and the only sound is birdsong echoing between the towers.',
    image: U('1470071459604-3b5ec3a7fe05'),
    gallery: [U('1470071459604-3b5ec3a7fe05'), U('1469474968028-56623f02e42e'), U('1523712999610-f77fbcfc3843')],
    rating: 4.8, saves: 3345, cost: '$$', difficulty: 'Medium', bestTime: 'April – June',
    transport: 'Park shuttle to Tianzi Mountain, then hike the western trails',
    popularity: 'Well Kept Secret', latitude: 29.3153, longitude: 110.4348,
    tips: ['Fog is common — that\'s the magic, not a problem.', 'Stay at a guesthouse inside the park to beat the gates.', 'The lesser-known Yangjiajie entrance has fewer crowds.']
  },
  {
    id: 11, name: 'St. Nectan\'s Glen Waterfall', country: 'United Kingdom', region: 'Cornwall',
    category: 'Hidden Waterfalls',
    description: 'A 18 m waterfall plunging through a hole in the rock at the end of a mossy woodland glen.',
    longDescription: 'A sacred site for centuries, St. Nectan\'s Glen is reached by a riverside path through ancient oak woodland. The Kieve — a rock basin carved by falling water — glows emerald on sunny afternoons. Visitors tie ribbons of intention to the trees, a practice dating back to Celtic pilgrims.',
    image: U('1469474968028-56623f02e42e'),
    gallery: [U('1469474968028-56623f02e42e'), U('1447752875215-b2761acb3c5d'), U('1502082553048-f009c37129b9')],
    rating: 4.7, saves: 1956, cost: '$', difficulty: 'Easy', bestTime: 'May – September',
    transport: 'Footpath from Trethevy, near Tintagel',
    popularity: 'Well Kept Secret', latitude: 50.6693, longitude: -4.6981,
    tips: ['A small honesty-box fee supports the glen\'s upkeep.', 'Wear boots — the riverside path stays muddy.', 'Pair with a visit to Tintagel Castle nearby.']
  },
  {
    id: 12, name: 'Saxon Switzerland Bastei Bridge', country: 'Germany', region: 'Sächsische Schweiz',
    category: 'Secret Viewpoints',
    description: 'A stone bridge threading between sandstone towers above the Elbe canyon.',
    longDescription: 'The Bastei has drawn painters and poets for 200 years, yet most visitors see it only from the parking-lot viewpoint. Walk the ridge trails in either direction and you\'ll find empty rock balconies hanging over the Elbe, where peregrine falcons ride the thermals below your feet.',
    image: U('1500534314209-a25ddb2bd429'),
    gallery: [U('1500534314209-a25ddb2bd429'), U('1464822759023-fed622ff2c3b'), U('1512100356356-de1b84283e18')],
    rating: 4.8, saves: 2874, cost: '$', difficulty: 'Easy', bestTime: 'May – October',
    transport: 'Bus from Dresden to Rathen, then a 20 min uphill walk',
    popularity: 'Trending', latitude: 50.9617, longitude: 14.0716,
    tips: ['Sunrise from the Ferdinandstein rocks is unforgettable.', 'Ferries cross the Elbe for riverside return loops.', 'Climbers: the area has 1,100+ sandstone climbing peaks.']
  },
  {
    id: 13, name: 'Huacachina Desert Oasis', country: 'Peru', region: 'Ica Region',
    category: 'Hidden Valleys',
    description: 'A palm-ringed natural lagoon surrounded by 300 m sand dunes in the Peruvian desert.',
    longDescription: 'Legend says a princess\'s mirror created this lagoon, and today Huacachina remains one of the last true desert oases in the Americas. Sandboard down mega-dunes at sunset, then watch the lights of Ica twinkle below as the lagoon reflects the stars. A village of 100 people guards this improbable green eye.',
    image: U('1518684079-3c830dcef090'),
    gallery: [U('1518684079-3c830dcef090'), U('1508672019048-805c876b67e2'), U('1472214103451-9374bd1c798e')],
    rating: 4.7, saves: 4120, cost: '$$', difficulty: 'Easy', bestTime: 'April – November',
    transport: 'Bus to Ica, then a 10 min taxi to the oasis',
    popularity: 'Trending', latitude: -14.0875, longitude: -75.7633,
    tips: ['Dune buggy tours at 4 pm catch golden-hour light.', 'Swimming in the lagoon is allowed but the water is mineral-rich.', 'Weekdays are far quieter than weekends.']
  },
  {
    id: 14, name: 'Waitomo Glowworm Cathedral', country: 'New Zealand', region: 'Waikato, North Island',
    category: 'Hidden Caves',
    description: 'A cave system where thousands of glowworms create a living starfield on the ceiling.',
    longDescription: 'Float in silence through the Waitomo caves and look up: the ceiling glitters like a galaxy. The glowworms (Arachnocampa luminosa) are the larvae of a fungus gnat, and their blue-green light is a hunting lure. Black-water rafting trips take you through underground rivers beneath the living constellations.',
    image: U('1476514525535-07fb3b4ae5f1'),
    gallery: [U('1476514525535-07fb3b4ae5f1'), U('1504280317859-8d10cb95a2a6'), U('1544551763-46a013bb70d5')],
    rating: 4.9, saves: 3890, cost: '$$', difficulty: 'Medium', bestTime: 'Year-round',
    transport: 'Shuttle from Auckland or Rotorua to Waitomo village',
    popularity: 'Well Kept Secret', latitude: -38.2607, longitude: 175.1038,
    tips: ['Choose a small-group tour — silence makes the glowworms brighter.', 'The dry walking tour suits all fitness levels.', 'No photos allowed on some tours; live in the moment.']
  },
  {
    id: 15, name: 'Faroe Islands Drangarnir Hike', country: 'Faroe Islands', region: 'Vagar',
    category: 'Secret Viewpoints',
    description: 'A hike to a sea arch standing alone in the Atlantic, away from every road.',
    longDescription: 'Drangarnir — the sea stack with a hole worn clean through it — can only be reached on foot across private land with a local guide. The trail crosses open moor where sheep outnumber people a hundred to one, ending at cliffs where waves explode against basalt 70 m below.',
    image: U('1500530855697-b586d89ba3ee'),
    gallery: [U('1500530855697-b586d89ba3ee'), U('1466442929976-97f336a657be'), U('1518837695005-2083093ee35b')],
    rating: 4.8, saves: 2450, cost: '$$', difficulty: 'Medium', bestTime: 'June – August',
    transport: 'Guided hike only — departs from the village of Bøur',
    popularity: 'Hidden Gem', latitude: 62.0900, longitude: -7.3180,
    tips: ['Booking a guide is legally required (farmland access).', 'Weather changes fast — pack waterproofs even in summer.', 'Bøur village has a lovely cafe for post-hike soup.']
  },
  {
    id: 16, name: 'Koh Adang Secret Ridge Camp', country: 'Thailand', region: 'Satun, Andaman Sea',
    category: 'Secret Campsites',
    description: 'A ridgeline camp on an uninhabited island opposite Koh Lipe, with 360° Andaman views.',
    longDescription: 'Most visitors to Koh Lipe never look across the channel at Koh Adang, its wild bigger sister. A two-hour jungle trail climbs to a ranger campsite on the spine of the island. From your tent you watch sunset over the sea on one side and moonrise over Lipe\'s lights on the other.',
    image: U('1559827260-dc66d52bef19'),
    gallery: [U('1559827260-dc66d52bef19'), U('1505142468610-359e7d316be0'), U('1519046904884-53103b34b206')],
    rating: 4.7, saves: 1732, cost: '$', difficulty: 'Medium', bestTime: 'November – April',
    transport: 'Longtail boat from Koh Lipe, then jungle trail',
    popularity: 'Hidden Gem', latitude: 6.5333, longitude: 99.2667,
    tips: ['Register with the national park rangers before camping.', 'Bring all food and water — nothing is sold on the island.', 'The waterfall trail on the east side is worth the detour.']
  },
  {
    id: 17, name: 'Tepui Summit Lost World', country: 'Venezuela', region: 'Canaima, Gran Sabana',
    category: 'Ancient Places',
    description: 'The plateau that inspired "The Lost World" — a billion-year-old island in the sky.',
    longDescription: 'Mount Roraima is one of Earth\'s oldest rock formations, its summit a landscape of black stone, carnivorous plants and crystal valleys where 70% of species exist nowhere else. A six-day trek from the Pemón village of Paraitepuy crosses rivers and cloud forest before the final ramp climb onto the roof of South America.',
    image: U('1509316785289-025f5b846b35'),
    gallery: [U('1509316785289-025f5b846b35'), U('1472214103451-9374bd1c798e'), U('1469474968028-56623f02e42e')],
    rating: 4.9, saves: 1320, cost: '$$$', difficulty: 'Hard', bestTime: 'December – March',
    transport: 'Organized trek from Santa Elena de Uairén',
    popularity: 'Hidden Gem', latitude: 5.1433, longitude: -60.7625,
    tips: ['A guide is mandatory and genuinely useful.', 'Carnivorous pitcher plants on the summit trap insects — do not touch.', 'Pack for cold rain even in dry season.']
  },
  {
    id: 18, name: 'Wadi Shab Emerald Pools', country: 'Oman', region: 'Al Sharqiyah',
    category: 'Hidden Waterfalls',
    description: 'A canyon walk ending in a swim-through cave to a waterfall-fed emerald pool.',
    longDescription: 'Cross Wadi Shab by boat (one Omani rial), then follow the palm-shaded canyon trail along turquoise pools. The finale is the best-kept secret in Oman: swim through a narrow cave opening — or wade waist-deep — into a grotto where a waterfall pours into a glowing green pool.',
    image: U('1547234935-80c7145ec969'),
    gallery: [U('1547234935-80c7145ec969'), U('1505142468610-359e7d316be0'), U('1519046904884-53103b34b206')],
    rating: 4.8, saves: 3561, cost: '$', difficulty: 'Medium', bestTime: 'October – April',
    transport: 'Boat crossing from the highway, then 45 min canyon hike',
    popularity: 'Trending', latitude: 22.8372, longitude: 59.2419,
    tips: ['Waterproof bag is essential for phones in the cave swim.', 'Weekend mornings are busiest — go on a weekday.', 'Cliff jumping spots exist but check depth first.']
  },
  {
    id: 19, name: 'Bisti Badlands Alien Hoodoos', country: 'United States', region: 'New Mexico',
    category: 'Forgotten Ruins',
    description: 'A wilderness of cracked earth, stone wings and hoodoos that look like another planet.',
    longDescription: 'The Bisti/De-Na-Zin Wilderness contains no trails, no signs, no water — only 45,000 acres of eroded fantasy. Stone wings, eerie balanced rocks and the famous "Alien Throne" appear and vanish in the heat shimmer. Navigation skills are essential; the reward is total silence and landscapes that defy belief.',
    image: U('1509316975850-ff9c5deb0cd9'),
    gallery: [U('1509316975850-ff9c5deb0cd9'), U('1472214103451-9374bd1c798e'), U('1519681393784-d120267933ba')],
    rating: 4.6, saves: 1430, cost: '$', difficulty: 'Hard', bestTime: 'March – May',
    transport: 'High-clearance vehicle to the trailhead, then cross-country hiking',
    popularity: 'Hidden Gem', latitude: 36.2616, longitude: -108.2506,
    tips: ['Download offline maps — there is zero phone signal.', 'Carry 4+ liters of water per person.', 'Golden hour transforms the hoodoos into fire.']
  },
  {
    id: 20, name: 'Melissani Cave Lake', country: 'Greece', region: 'Kefalonia, Ionian Islands',
    category: 'Hidden Caves',
    description: 'A collapsed cave where a sunbeam turns an underground lake the color of liquid sapphire.',
    longDescription: 'Part of the cave roof fell in millennia ago, opening Melissani to the sky. At midday, sunlight strikes the brackish lake directly, illuminating the water so intensely that boats appear to float on light. Ancient Greeks believed nymphs lived here — standing in that beam, you\'ll believe it too.',
    image: U('1507525428034-b723cf961d3e', 1200),
    gallery: [U('1507525428034-b723cf961d3e'), U('1544551763-46a013bb70d5'), U('1505142468610-359e7d316be0')],
    rating: 4.8, saves: 4022, cost: '$', difficulty: 'Easy', bestTime: 'May – October',
    transport: 'Short walk from the car park near Sami',
    popularity: 'Trending', latitude: 38.2569, longitude: 20.6469,
    tips: ['Boat rides run 9 am – 7 pm in season.', 'The best light is between 11 am and 1 pm.', 'Combine with Drogarati Cave 3 km away.']
  },
  {
    id: 21, name: 'Hidden Bay Palawan', country: 'Philippines', region: 'Palawan',
    category: 'Secret Lagoons',
    description: 'A limestone maze of lagoons reachable only by kayak through a low cave passage.',
    longDescription: 'Beyond El Nido\'s famous lagoons lie unnamed bays where karst walls hide pools of impossible clarity. Local boatmen know the passages — timing the tides, ducking through cave mouths into cathedrals of stone where the only footprint on the sand is your own.',
    image: U('1559494007-9f5847c49d94'),
    gallery: [U('1559494007-9f5847c49d94'), U('1544551763-46a013bb70d5'), U('1530789253388-582c481c54b0')],
    rating: 4.9, saves: 3788, cost: '$$', difficulty: 'Medium', bestTime: 'November – May',
    transport: 'Private bangka boat from El Nido with local guide',
    popularity: 'Trending', latitude: 11.1800, longitude: 119.3900,
    tips: ['Negotiate a private tour and name "hidden lagoons" as your goal.', 'Dry bags are essential for kayaking between lagoons.', 'The dry season brings calmer seas and better visibility.']
  },
  {
    id: 22, name: 'Göreme Hidden Rock Churches', country: 'Turkey', region: 'Cappadocia',
    category: 'Ancient Places',
    description: 'Byzantine churches carved inside fairy chimneys, their frescoes still glowing after 1,000 years.',
    longDescription: 'Everyone comes to Cappadocia for the balloons, but the real wonder is underground and inside stone. Beyond the open-air museum, dozens of unmarked rock churches hide in valleys like Zelve and Soganli — carved, painted and forgotten by empires. Finding them feels like discovering a library where every book is a cave.',
    image: U('1541696432-82c6da0ce7bf'),
    gallery: [U('1541696432-82c6da0ce7bf'), U('1516483638261-f4dbaf036963'), U('1469474968028-56623f02e42e')],
    rating: 4.7, saves: 2150, cost: '$$', difficulty: 'Easy', bestTime: 'April – June',
    transport: 'Hire a scooter or join a valley hiking tour from Göreme',
    popularity: 'Well Kept Secret', latitude: 38.6431, longitude: 34.8287,
    tips: ['A flashlight app is not enough — bring a real torch.', 'Ask your pension owner for valley church maps.', 'Sunrise balloons viewed from Rose Valley are free.']
  },
  {
    id: 23, name: 'Mount Rinjani Crater Rim Camp', country: 'Indonesia', region: 'Lombok',
    category: 'Secret Mountains',
    description: 'Camp on the rim of a volcano above a turquoise crater lake few ever reach.',
    longDescription: 'The two-day trek to Mount Rinjani\'s crater rim is one of Southeast Asia\'s great adventures: savanna slopes, monkey forests, and then the reveal — Segara Anak, a crescent lake of molten blue inside the caldera, with the active cone of Barujari smoking across the water. Camp at the rim and watch the lake change color at dusk.',
    image: U('1454496522488-7a8e488e8606'),
    gallery: [U('1454496522488-7a8e488e8606'), U('1464822759023-fed622ff2c3b'), U('1501785888041-af3ef285b470')],
    rating: 4.8, saves: 2910, cost: '$$', difficulty: 'Hard', bestTime: 'April – October',
    transport: 'Guided trek from Senaru or Sembalun village',
    popularity: 'Trending', latitude: -8.4113, longitude: 116.4578,
    tips: ['Book a reputable operator — porters carry camping gear.', 'Nights at the rim drop below 10°C; bring layers.', 'The summit push starts at 2 am for sunrise.']
  },
  {
    id: 24, name: 'Te Waihora Star Dune Night Camp', country: 'New Zealand', region: 'Farewell Spit, South Island',
    category: 'Secret Campsites',
    description: 'Camp on the highest sand dune in the Southern Hemisphere under a designated dark sky.',
    longDescription: 'At the far end of Farewell Spit, Te Paki\'s giant dunes roll to the horizon in a region with some of the darkest skies in the world. Sandboard by day, then watch the Milky Way rise over the Tasman Sea at night. The nearest streetlight is 40 km away — bring a star map, not a flashlight.',
    image: U('1419242902214-272b3f66ee7a'),
    gallery: [U('1419242902214-272b3f66ee7a'), U('1519681393784-d120267933ba'), U('1472214103451-9374bd1c798e')],
    rating: 4.6, saves: 1085, cost: '$', difficulty: 'Medium', bestTime: 'December – February',
    transport: 'Drive to Te Paki Stream car park, then dune walk',
    popularity: 'Hidden Gem', latitude: -34.4900, longitude: 172.7000,
    tips: ['Camping is permitted in the recreation reserve — leave no trace.', 'Sandboards are rentable in nearby Kaitaia.', 'New moon nights give the best galactic views.']
  }
];

const CATEGORIES = [
  { name: 'Hidden Beaches',        icon: '🏝️', image: U('1507525428034-b723cf961d3e', 800) },
  { name: 'Hidden Waterfalls',     icon: '💧', image: U('1433086966358-54859d0ed716', 800) },
  { name: 'Secret Mountains',      icon: '🏔️', image: U('1464822759023-fed622ff2c3b', 800) },
  { name: 'Hidden Forests',        icon: '🌲', image: U('1447752875215-b2761acb3c5d', 800) },
  { name: 'Secret Campsites',      icon: '🏕️', image: U('1519681393784-d120267933ba', 800) },
  { name: 'Forgotten Villages',    icon: '🏘️', image: U('1516483638261-f4dbaf036963', 800) },
  { name: 'Ancient Places',        icon: '🗿', image: U('1541696432-82c6da0ce7bf', 800) },
  { name: 'Hidden Caves',          icon: '🕳️', image: U('1476514525535-07fb3b4ae5f1', 800) },
  { name: 'Secret Lagoons',        icon: '🌊', image: U('1530789253388-582c481c54b0', 800) },
  { name: 'Secret Viewpoints',     icon: '🌅', image: U('1500534314209-a25ddb2bd429', 800) },
  { name: 'Hidden Valleys',        icon: '🏞️', image: U('1544735716-392fe2489ffa', 800) },
  { name: 'Forgotten Ruins',       icon: '🏛️', image: U('1509316975850-ff9c5deb0cd9', 800) }
];

const COUNTRIES = [
  { name: 'Sri Lanka',        flag: '🇱🇰', image: U('1433086966358-54859d0ed716', 800) },
  { name: 'Japan',            flag: '🇯🇵', image: U('1447752875215-b2761acb3c5d', 800) },
  { name: 'Indonesia',        flag: '🇮🇩', image: U('1530789253388-582c481c54b0', 800) },
  { name: 'Thailand',         flag: '🇹🇭', image: U('1505142468610-359e7d316be0', 800) },
  { name: 'Italy',            flag: '🇮🇹', image: U('1516483638261-f4dbaf036963', 800) },
  { name: 'Greece',           flag: '🇬🇷', image: U('1507525428034-b723cf961d3e', 800) },
  { name: 'Nepal',            flag: '🇳🇵', image: U('1544735716-392fe2489ffa', 800) },
  { name: 'New Zealand',      flag: '🇳🇿', image: U('1476514525535-07fb3b4ae5f1', 800) },
  { name: 'France',           flag: '🇫🇷', image: U('1502602898657-3e91760cbb34', 800) },
  { name: 'Philippines',      flag: '🇵🇭', image: U('1559494007-9f5847c49d94', 800) },
  { name: 'Mexico',           flag: '🇲🇽', image: U('1518105779142-d975f22f1b0a', 800) },
  { name: 'Australia',        flag: '🇦🇺', image: U('1506973035872-a4ec16b8e8d0', 800) },
  { name: 'Albania',          flag: '🇦🇱', image: U('1507525428034-b723cf961d3e', 800) },
  { name: 'Norway',           flag: '🇳🇴', image: U('1519681393784-d120267933ba', 800) },
  { name: 'Peru',             flag: '🇵🇪', image: U('1518684079-3c830dcef090', 800) },
  { name: 'Oman',             flag: '🇴🇲', image: U('1547234935-80c7145ec969', 800) }
];

/* ---------- Helpers ---------- */
function getUserPlaces() {
  try { return JSON.parse(localStorage.getItem('hw_submissions') || '[]'); }
  catch (e) { return []; }
}

function getAllPlaces() {
  return PLACES.concat(getUserPlaces());
}

function getPlaceById(id) {
  return getAllPlaces().find(p => String(p.id) === String(id));
}

function getCountriesWithCounts() {
  const all = getAllPlaces();
  return COUNTRIES.map(c => ({
    ...c,
    count: all.filter(p => p.country === c.name).length
  }));
}

function getCategoriesWithCounts() {
  const all = getAllPlaces();
  return CATEGORIES.map(c => ({
    ...c,
    count: all.filter(p => p.category === c.name).length
  }));
}

function esc(str) {
  return String(str ?? '').replace(/[&<>"']/g, s => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[s]));
}
