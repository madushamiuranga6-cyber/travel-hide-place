/* =========================================================
   HIDEWORLD PLACE — add-place.js
   Submit new hidden places -> localStorage (backend-ready).
   ========================================================= */

(function () {
  'use strict';

  const form = document.getElementById('add-place-form');
  if (!form) return;

  function getSubs() {
    try { return JSON.parse(localStorage.getItem('hw_submissions') || '[]'); }
    catch (e) { return []; }
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    const val = id => document.getElementById(id).value.trim();
    const name = val('ap-name'), country = val('ap-country'),
          region = val('ap-region'), category = val('ap-category'),
          description = val('ap-description'), bestTime = val('ap-besttime'),
          cost = val('ap-cost'), difficulty = val('ap-difficulty'),
          image = val('ap-image'), extra = val('ap-extra');

    const msgEl = form.querySelector('.form-msg');
    function fail(text) { msgEl.textContent = text; msgEl.className = 'form-msg error'; msgEl.scrollIntoView({ behavior: 'smooth', block: 'center' }); }

    if (name.length < 3) return fail('Please enter the place name (min 3 characters).');
    if (!country) return fail('Please select a country.');
    if (!region) return fail('Please enter the city or region.');
    if (!category) return fail('Please select a category.');
    if (description.length < 20) return fail('Please write a description of at least 20 characters.');
    if (image && !/^https?:\/\//i.test(image)) return fail('Image URL must start with http:// or https://');

    const subs = getSubs();
    const place = {
      id: 1000 + subs.length + 1,
      name, country, region, category, description,
      longDescription: description + (extra ? '\n\n' + extra : ''),
      image: image || FALLBACK_IMG,
      gallery: image ? [image] : [FALLBACK_IMG],
      rating: 5.0, saves: 1, cost: cost || '$',
      difficulty: difficulty || 'Medium',
      bestTime: bestTime || 'Year-round',
      transport: 'Details coming soon',
      popularity: 'Newly Added',
      latitude: 10 + Math.random() * 40,
      longitude: -60 + Math.random() * 120,
      tips: ['Submitted by a community member — verify access locally.', 'Respect local communities and private property.'],
      userSubmitted: true
    };
    subs.push(place);
    localStorage.setItem('hw_submissions', JSON.stringify(subs));

    msgEl.textContent = '✅ Place submitted successfully! Our team will review it. Thank you for sharing a hidden gem.';
    msgEl.className = 'form-msg success';
    form.reset();
    hwToast('✅ Place submitted successfully', 'accent');
    msgEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
})();
