/* =========================================================
   HIDEWORLD PLACE — search.js
   Explore page (filters/sorting/pagination) + Place details
   page rendering.
   ========================================================= */

(function () {
  'use strict';

  const ICON_HEART = window.HW_ICONS.ICON_HEART;

  /* =============== EXPLORE PAGE =============== */
  function initExplore() {
    const grid = document.getElementById('explore-grid');
    if (!grid) return;

    // Populate country/category dropdowns before applying URL params
    const countries = getCountriesWithCounts().filter(c => c.count > 0);
    document.getElementById('f-country').innerHTML = '<option value="">All Countries</option>' +
      countries.map(c => `<option value="${esc(c.name)}">${c.flag} ${esc(c.name)}</option>`).join('');
    document.getElementById('f-category').innerHTML = '<option value="">All Categories</option>' +
      getCategoriesWithCounts().map(c => `<option value="${esc(c.name)}">${c.icon} ${esc(c.name)}</option>`).join('');

    const state = {
      q: '', country: '', category: '', region: '',
      minRating: 0, difficulty: '', cost: '', season: '',
      sort: 'popular', shown: 9
    };
    const PAGE_SIZE = 9;

    // Read URL params (?q=, ?country=, ?category=)
    const params = new URLSearchParams(location.search);
    if (params.get('q')) state.q = params.get('q');
    if (params.get('country')) state.country = params.get('country');
    if (params.get('category')) state.category = params.get('category');
    document.getElementById('f-search').value = state.q;
    document.getElementById('f-country').value = state.country;
    document.getElementById('f-category').value = state.category;

    // Populate region dropdown dynamically
    function refreshRegions() {
      const regions = [...new Set(getAllPlaces()
        .filter(p => !state.country || p.country === state.country)
        .map(p => p.region))].sort();
      const sel = document.getElementById('f-region');
      sel.innerHTML = '<option value="">All Regions</option>' +
        regions.map(r => `<option ${r === state.region ? 'selected' : ''}>${esc(r)}</option>`).join('');
    }
    refreshRegions();

    function seasonMatches(p) {
      if (!state.season) return true;
      const bt = (p.bestTime || '').toLowerCase();
      if (state.season === 'spring') return bt.includes('march') || bt.includes('april') || bt.includes('may') || bt.includes('june');
      if (state.season === 'summer') return bt.includes('june') || bt.includes('july') || bt.includes('august') || bt.includes('september');
      if (state.season === 'autumn') return bt.includes('september') || bt.includes('october') || bt.includes('november');
      if (state.season === 'winter') return bt.includes('december') || bt.includes('january') || bt.includes('february');
      if (state.season === 'year') return bt.includes('year');
      return true;
    }

    function getFiltered() {
      let items = getAllPlaces().filter(p =>
        (!state.q || [p.name, p.country, p.region, p.category].join(' ').toLowerCase().includes(state.q.toLowerCase())) &&
        (!state.country || p.country === state.country) &&
        (!state.category || p.category === state.category) &&
        (!state.region || p.region === state.region) &&
        Number(p.rating) >= state.minRating &&
        (!state.difficulty || p.difficulty === state.difficulty) &&
        (!state.cost || p.cost === state.cost) &&
        seasonMatches(p)
      );
      const sorters = {
        popular: (a, b) => b.saves - a.saves,
        recent: (a, b) => (b.id - a.id),
        rating: (a, b) => b.rating - a.rating,
        saved: (a, b) => b.saves - a.saves
      };
      return items.sort(sorters[state.sort] || sorters.popular);
    }

    function render() {
      const items = getFiltered();
      const slice = items.slice(0, state.shown);
      document.getElementById('results-count').innerHTML =
        `Showing <b>${slice.length}</b> of <b>${items.length}</b> hidden places` +
        (state.q ? ` for “${esc(state.q)}”` : '');
      if (!slice.length) {
        grid.innerHTML = `
          <div class="empty-state" style="grid-column:1/-1">
            <div class="big">🧭</div>
            <h3>No hidden places found</h3>
            <p>Try adjusting your filters or search term.</p>
          </div>`;
      } else {
        grid.innerHTML = slice.map(p => hwCard(p)).join('');
      }
      document.getElementById('load-more').style.display =
        items.length > state.shown ? '' : 'none';
      document.getElementById('load-more').textContent = `Load More (${items.length - slice.length} left)`;
      hwInitReveal();
    }

    function bind(id, key, isNum) {
      const el = document.getElementById(id);
      el.addEventListener(isNum ? 'change' : 'input', () => {
        state[key] = isNum ? parseFloat(el.value) || 0 : el.value;
        state.shown = PAGE_SIZE;
        if (key === 'country') { state.region = ''; refreshRegions(); }
        render();
      });
    }
    bind('f-search', 'q');
    bind('f-country', 'country');
    bind('f-category', 'category');
    bind('f-region', 'region');
    bind('f-rating', 'minRating', true);
    bind('f-difficulty', 'difficulty');
    bind('f-cost', 'cost');
    bind('f-season', 'season');
    bind('f-sort', 'sort');

    document.getElementById('filters-reset').addEventListener('click', () => {
      Object.assign(state, { q: '', country: '', category: '', region: '', minRating: 0, difficulty: '', cost: '', season: '', sort: 'popular', shown: PAGE_SIZE });
      ['f-search', 'f-country', 'f-category', 'f-region', 'f-difficulty', 'f-cost', 'f-season'].forEach(id => document.getElementById(id).value = '');
      document.getElementById('f-rating').value = '0';
      document.getElementById('f-sort').value = 'popular';
      render();
      hwToast('Filters cleared', 'accent');
    });

    document.getElementById('load-more').addEventListener('click', () => {
      state.shown += PAGE_SIZE;
      render();
    });

    render();
  }

  /* =============== PLACE DETAILS PAGE =============== */
  function initPlaceDetails() {
    const root = document.getElementById('place-detail');
    if (!root) return;

    const id = new URLSearchParams(location.search).get('id');
    const p = getPlaceById(id);
    if (!p) {
      root.innerHTML = `
        <div class="container section"><div class="empty-state">
          <div class="big">🗺️</div><h3>Place not found</h3>
          <p>This hidden place may have been removed.</p>
          <p style="margin-top:18px"><a class="btn btn-primary" href="explore.html">Explore Hidden Places</a></p>
        </div></div>`;
      return;
    }
    document.title = p.name + ' — HIDEWORLD PLACE';

    const nearby = getAllPlaces()
      .filter(x => x.id !== p.id && (x.country === p.country || x.category === p.category))
      .sort((a, b) => (b.country === p.country) - (a.country === p.country))
      .slice(0, 3);

    const faved = hwGetFavs().includes(Number(p.id));
    root.innerHTML = `
      <section class="detail-hero">
        <img src="${esc(p.image)}" alt="${esc(p.name)}" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">
        <div class="container detail-hero-content">
          <span class="badge badge-accent" style="font-size:.8rem">${esc(p.category)}</span>
          <h1 style="margin-top:10px">${esc(p.name)}</h1>
          <div class="detail-meta">
            <span class="badge">${window.HW_ICONS.ICON_PIN} ${esc(p.region)}, ${esc(p.country)}</span>
            <span class="badge">★ ${Number(p.rating).toFixed(1)} (${Number(p.saves || 0).toLocaleString()} saves)</span>
            <span class="badge">${esc(p.difficulty)}</span>
          </div>
        </div>
        <div class="container" style="position:relative">
          <div class="detail-actions">
            <button class="btn ${faved ? 'btn-accent' : 'btn-ghost'} btn-sm" data-fav-id="${p.id}">
              ${ICON_HEART} <span class="fav-label">${faved ? 'Saved' : 'Save'}</span>
            </button>
            <button class="btn btn-ghost btn-sm" data-share="place.html?id=${p.id}">🔗 Share</button>
          </div>
        </div>
      </section>

      <section class="section" style="padding-top:56px">
        <div class="container detail-grid">
          <div>
            <div class="prose reveal">
              <span class="kicker" style="color:var(--secondary);font-weight:700;letter-spacing:.14em;text-transform:uppercase;font-size:.78rem">About this place</span>
              <h2 style="margin:8px 0 18px">The story behind ${esc(p.name)}</h2>
              <p>${esc(p.longDescription || p.description)}</p>
            </div>

            <div style="margin-top:48px" class="reveal">
              <span class="kicker" style="color:var(--secondary);font-weight:700;letter-spacing:.14em;text-transform:uppercase;font-size:.78rem">Things to know</span>
              <h2 style="margin:8px 0 18px">Traveler tips</h2>
              <div class="tips-list">
                ${(p.tips || []).map((t, i) => `<div class="tip-item"><span class="dot">${i + 1}</span><span>${esc(t)}</span></div>`).join('')}
              </div>
            </div>

            <div style="margin-top:48px" class="reveal">
              <span class="kicker" style="color:var(--secondary);font-weight:700;letter-spacing:.14em;text-transform:uppercase;font-size:.78rem">Gallery</span>
              <h2 style="margin:8px 0 18px">Photo gallery</h2>
              <div class="gallery-grid">
                ${(p.gallery && p.gallery.length ? p.gallery : [p.image]).map(g =>
                  `<img src="${esc(g)}" alt="${esc(p.name)}" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">`).join('')}
              </div>
            </div>

            <div style="margin-top:48px" class="reveal">
              <span class="kicker" style="color:var(--secondary);font-weight:700;letter-spacing:.14em;text-transform:uppercase;font-size:.78rem">Location</span>
              <h2 style="margin:8px 0 18px">Where to find it</h2>
              <div class="mini-map">
                <div class="grid-lines"></div>
                <span class="map-pin-big" style="left:50%;top:52%">
                  <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a7.5 7.5 0 0 0-7.5 7.5c0 5.6 7.5 12.5 7.5 12.5s7.5-6.9 7.5-12.5A7.5 7.5 0 0 0 12 2zm0 10.2a2.7 2.7 0 1 1 0-5.4 2.7 2.7 0 0 1 0 5.4z"/></svg>
                </span>
                <span class="coords">📍 ${Number(p.latitude).toFixed(3)}, ${Number(p.longitude).toFixed(3)} · Interactive map: <a href="map.html" style="color:var(--accent);text-decoration:underline">Open Map</a></span>
              </div>
            </div>
          </div>

          <aside class="info-panel reveal">
            <h3>📋 Good to know</h3>
            <ul class="info-list">
              <li><span>📍 Location</span><b>${esc(p.region)}</b></li>
              <li><span>🌎 Country</span><b>${esc(p.country)}</b></li>
              <li><span>🏷️ Category</span><b>${esc(p.category)}</b></li>
              <li><span>⭐ Rating</span><b>${Number(p.rating).toFixed(1)} / 5</b></li>
              <li><span>💰 Estimated cost</span><b>${esc(p.cost || '$')}</b></li>
              <li><span>🕐 Best time to visit</span><b>${esc(p.bestTime || 'Year-round')}</b></li>
              <li><span>🚗 Transportation</span><b>${esc(p.transport || 'Local transport')}</b></li>
              <li><span>🥾 Difficulty</span><b>${esc(p.difficulty)}</b></li>
              <li><span>👥 Popularity</span><b>${esc(p.popularity || 'Hidden Gem')}</b></li>
            </ul>
            <a class="btn btn-primary btn-block" style="margin-top:18px" href="map.html">🗺️ View on Map</a>
          </aside>
        </div>
      </section>

      ${nearby.length ? `
      <section class="section" style="padding-top:0">
        <div class="container">
          <div class="section-head reveal">
            <div><span class="kicker" style="color:var(--secondary);font-weight:700;letter-spacing:.14em;text-transform:uppercase;font-size:.78rem">Keep exploring</span>
            <h2>Nearby hidden places</h2></div>
            <a class="link-arrow" href="explore.html?country=${encodeURIComponent(p.country)}">All in ${esc(p.country)} ${window.HW_ICONS.ICON_ARROW}</a>
          </div>
          <div class="grid-cards">${nearby.map(x => hwCard(x)).join('')}</div>
        </div>
      </section>` : ''}`;

    // Lightbox for gallery
    root.querySelectorAll('.gallery-grid img').forEach(img => {
      img.addEventListener('click', () => hwLightbox(img.src));
    });

    hwInitReveal();
  }

  /* =============== CATEGORIES PAGE =============== */
  function initCategoriesPage() {
    const grid = document.getElementById('categories-grid');
    if (!grid) return;
    grid.innerHTML = getCategoriesWithCounts().map(c => `
      <a class="cat-card reveal" href="explore.html?category=${encodeURIComponent(c.name)}">
        <img src="${esc(c.image)}" alt="${esc(c.name)}" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'">
        <div class="cat-info">
          <span class="cat-icon">${c.icon}</span>
          <h3>${esc(c.name)}</h3>
          <span>${c.count} hidden place${c.count === 1 ? '' : 's'}</span>
          <span class="explore-mini">Explore ${window.HW_ICONS.ICON_ARROW}</span>
        </div>
      </a>`).join('');
    hwInitReveal();
  }

  /* =============== COUNTRIES PAGE =============== */
  function initCountriesPage() {
    const grid = document.getElementById('countries-grid');
    if (!grid) return;
    const input = document.getElementById('country-search');
    function render() {
      const q = (input.value || '').trim().toLowerCase();
      const list = getCountriesWithCounts().filter(c => c.name.toLowerCase().includes(q));
      grid.innerHTML = list.map(c => `
        <div class="country-card reveal">
          <div class="card-media">
            <a href="explore.html?country=${encodeURIComponent(c.name)}"><img src="${esc(c.image)}" alt="${esc(c.name)}" loading="lazy" onerror="this.onerror=null;this.src='${FALLBACK_IMG}'"></a>
            <span class="country-flag">${c.flag}</span>
          </div>
          <div class="card-body">
            <h3><a href="explore.html?country=${encodeURIComponent(c.name)}">${esc(c.name)}</a></h3>
            <p>${c.count} hidden place${c.count === 1 ? '' : 's'} discovered</p>
            <div class="card-actions"><a class="btn btn-outline btn-sm" href="explore.html?country=${encodeURIComponent(c.name)}">Explore ${window.HW_ICONS.ICON_ARROW}</a></div>
          </div>
        </div>`).join('') || `<div class="empty-state" style="grid-column:1/-1"><div class="big">🧭</div><h3>No countries found</h3><p>Try a different search term.</p></div>`;
      hwInitReveal();
    }
    input.addEventListener('input', render);
    render();
  }

  window.hwPageInit = function () {
    initExplore();
    initPlaceDetails();
    initCategoriesPage();
    initCountriesPage();
  };
})();
